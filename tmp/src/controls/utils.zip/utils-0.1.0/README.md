TopCoat utilities
